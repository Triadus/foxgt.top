// English tips for smilies
var smileL = {
	"smile": 		"Smile",
	"happy": 		"Happy",
	"sad": 			"Sad",
	"wink": 		"Winking",
	"grin": 		"Grin",
	"surprised":	"Surprised",
	"tongue":		"Tongue sticking out",
	"confused":		"Confused",
	"sunglasses":	"Sunglasses",
	"angry":		"Angry",
	"inlove":		"In love",
	"sleeping":		"Sleeping",
	"rose":			"Rose",
	"angel":		"Angel",
	"devil":		"Devil",
	"kiss":			"Kiss"
};