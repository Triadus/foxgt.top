<?php
/*=====================
[BEGIN_COT_EXT]
Hooks=global
[END_COT_EXT]
=====================*/

/**
 * boxes plugin
 *
 * @author Roffun
 * @copyright Copyright (C) 2015 - today: Roffun | https://github.com/Roffun
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL.');
require_once cot_incfile('boxes', 'plug');
