<?php
/* ====================
[BEGIN_COT_EXT]
Code=admintheme
Name=Admin Theme
Description=Use admin theme with some modules
Version=1.0
Date=2012-may-15
Author=Gert Hengeveld
Copyright=Copyright (c) Cotonti Team 2008-2011
Notes=BSD License
SQL=
Auth_guests=
Lock_guests=RW12345A
Auth_members=R
Lock_members=W12345A
Recommends_modules=users
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
[END_COT_EXT_CONFIG]
==================== */

defined('COT_CODE') or die('Wrong URL');

?>
