<?php
/* ====================
[BEGIN_COT_EXT]
Code=banlist
Name=Banlist
Category=administration-management
Description=Banlist
Version=1.0.2
Date=2015-jan-13
Author=esclkm, Cotonti Team
Copyright=Copyright (c) Cotonti Team 2008-2016
Notes=BSD License
Auth_guests=R
Lock_guests=12345A
Auth_members=RW
Lock_members=
Recommends_modules=page,forums
Recommends_plugins=
[END_COT_EXT]
==================== */

defined('COT_CODE') or die('Wrong URL');
