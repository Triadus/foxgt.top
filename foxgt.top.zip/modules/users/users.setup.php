<?php
/* ====================
[BEGIN_COT_EXT]
Name=Users
Description=Users registration and profiles
Version=1.4.6
Date=2016-06-02
Author=Neocrome & Cotonti Team
Copyright=(c) Cotonti Team 2008-2016
Notes=BSD License
Auth_guests=R
Lock_guests=A
Auth_members=RW
Lock_members=
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
disablereg=01:radio::0:
maxusersperpage=02:string::50:
regrequireadmin=03:radio::0:
regnoactivation=04:radio::0:
useremailchange=05:radio::0:
user_email_noprotection=06:radio::0:
usertextmax=08:string::300:
usertextimg=09:radio::0:
[END_COT_EXT_CONFIG]
==================== */
