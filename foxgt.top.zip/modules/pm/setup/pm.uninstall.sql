/**
 * PM DB uninstall
 */

DROP TABLE IF EXISTS `cot_pm`;