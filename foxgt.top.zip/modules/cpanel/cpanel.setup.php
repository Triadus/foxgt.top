<?php
/* ====================
[BEGIN_COT_EXT]
Code=cpanel
Name=Admin Control Panel
Description=Admin Control Panel module for Cpanel admin theme
Version=0.0.4
Date=2017-03-16
Author=Kalnov Alexey    (kalnovalexey@yandex.ru)
Copyright=(с) 2014-2017 Portal30 Studio http://portal30.ru
Auth_guests=
Lock_guests=RW12345A
Auth_members=
Lock_members=
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
[END_COT_EXT_CONFIG]
==================== */

/**
 * Cpanel Module
 *
 * @package Cotonti
 * @subpackage  Admin
 * @author Kalnov Alexey <kalnovalexey@yandex.ru>
 * @copyright © Portal30 2014-2017 Studio http://portal30.ru
 */
defined('COT_CODE') or die('Wrong URL');