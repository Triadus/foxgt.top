<?php

$R['polls_icon_lock'] = '<img src="images/icons/'.$cfg['defaulticons'].'/lock.png" alt="" />';
$R['polls_icon_unlock'] = '<img src="images/icons/'.$cfg['defaulticons'].'/lock.png" alt="" />';
$R['polls_icon_delete'] = '<img src="images/icons/'.$cfg['defaulticons'].'/delete.png" alt="" />';
$R['polls_icon_reset'] = '<img src="images/icons/'.$cfg['defaulticons'].'/reset.png" alt="" />';
$R['polls_icon_bump'] = '<img src="images/icons/'.$cfg['defaulticons'].'/arrow-up.png" alt="" />';
$R['polls_icon_open'] = '<img src="images/icons/'.$cfg['defaulticons'].'/arrow-jump.png" alt="" />';
