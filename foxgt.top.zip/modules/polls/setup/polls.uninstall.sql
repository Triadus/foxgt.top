/**
 * Polls DB uninstall
 */

DROP TABLE IF EXISTS `cot_polls`;
DROP TABLE IF EXISTS `cot_polls_options`;
DROP TABLE IF EXISTS `cot_polls_voters`;