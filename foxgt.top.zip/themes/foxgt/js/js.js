$().ready(function() {


	// Initialize tooltip component
	$(function () {
			$('[data-toggle="tooltip"]').tooltip()
	})

	// Initialize popover component
	$(function () {
			$('[data-toggle="popover"]').popover()
	})

});
